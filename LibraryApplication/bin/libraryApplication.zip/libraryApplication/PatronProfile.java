package libraryApplication;

import javax.swing.JPanel;

public class PatronProfile extends JPanel {

}
